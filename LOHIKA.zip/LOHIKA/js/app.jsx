//Hello World!

let img = React.createElement('img', {src: 'https://www.google.com/search?q=react&client=firefox-b-ab&source=lnms&tbm=isch&sa=X&ved=0ahUKEwihlsn4zc7bAhVJfywKHcTnDqIQ_AUIDCgD&biw=1680&bih=913#imgrc=xuWwA1EW_0fZtM:'});
let h1 = React.createElement('h1', null, 'Hello, World!');
let parag = React.createElement('p', null, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime, odio.');

let container = React.createElement('div', {className: 'container'}, img, h1, parag);
let root = document.getElementById('root');


ReactDOM.render(container, root);




//Сервер
const express = require('express');
const app = express();
const port = 3000;
app.listen(port, () => {
    console.log('Hello world!!! ' + port);
});

